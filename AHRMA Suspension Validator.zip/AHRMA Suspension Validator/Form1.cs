﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AHRMA_Suspension_Valididator
{
    
    public partial class Form1 : Form
    {
        // Connect to database
        SqlConnection DbConnect = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\Rider\\source\\repos\\AHRMA Suspension Validator\\ASV.mdf\";Integrated Security=True;Connect Timeout=30");

        // declare global variables
        int Dim_a;
        int Dim_b;
        int Dim_c;
        int Dim_d;
        int Dim_L0;
        int Dim_s;
        double Fa;

        public Form1()
        {
            InitializeComponent();
            RefreshRacerGrid();
            Message.Visible = false;
            pictureBox2.Visible = false;
            Label_fa.Visible = false;
            Instructions.Visible = false;
            Save.Visible = false;
        }

       // Method to calculate suspension travel
        private double SuspensionTravel(int a, int b, int c, int d, int L0, int s)
        {
            double Fr;
            
            Fr = a * (Math.Acos((b * b + c * c + d * d - L0 * L0) / (2 * c * Math.Sqrt(b * b + d * d))) - Math.Acos((b * b + c * c + d * d - ((L0 - s) * (L0 - s))) / (2 * c * Math.Sqrt(b * b + d * d))));
            Fa = 2 * a * Math.Sin(Fr / (2 * a));
            Fa = Math.Round(Fa, 2);
            return Fa;
        }

        // Validate user input and call method suspensiontravel() to calculate.
        private void Calculate_Click(object sender, EventArgs e)
        {
            // Validating Form
            Boolean Validated = true;
         
            errorProvider_RacerName.Clear();
            if (string.IsNullOrEmpty(RacerName.Text))
            {
                errorProvider_RacerName.SetError(RacerName, "Required");
                Validated = false;
            }
            errorProvider_BikeYear.Clear();
            if (BikeYear.SelectedItem == null)
            {
                errorProvider_BikeYear.SetError(BikeYear, "Required");
                Validated = false;
            }
            errorProvider_BikeBrand.Clear();
            if (string.IsNullOrEmpty(BikeBrand.Text))
            {
                errorProvider_BikeBrand.SetError(BikeBrand, "Required");
                Validated = false;
            }
            errorProvider_BikeModel.Clear();
            if (string.IsNullOrEmpty(BikeModel.Text))
            {
                errorProvider_BikeModel.SetError(BikeModel, "Required");
                Validated = false;
            }
            errorProvider_Dimension_a.Clear();
            if (!int.TryParse(Dimension_a.Text, out Dim_a))
            {
                errorProvider_Dimension_a.SetError(Dimension_a, "Invalid");
                Validated = false;
            }
            errorProvider_Dimension_b.Clear();
            if (!int.TryParse(Dimension_b.Text, out Dim_b))
            {
                errorProvider_Dimension_b.SetError(Dimension_b, "Invalid");
                Validated = false;
            }
            errorProvider_Dimension_c.Clear();
            if (!int.TryParse(Dimension_c.Text, out Dim_c))
            {
                errorProvider_Dimension_c.SetError(Dimension_c, "Invalid");
                Validated = false;
            }
            errorProvider_Dimension_d.Clear();
            if (!int.TryParse(Dimension_d.Text, out Dim_d))
            {
                errorProvider_Dimension_d.SetError(Dimension_d, "Invalid");
                Validated = false;
            }
            errorProvider_Dimension_L0.Clear();
            if (!int.TryParse(Dimension_L0.Text, out Dim_L0))
            {
                errorProvider_Dimension_L0.SetError(Dimension_L0, "Invalid");
                Validated = false;
            }
            errorProvider_Dimension_s.Clear();
            if (!int.TryParse(Dimension_s.Text, out Dim_s))
            {
                errorProvider_Dimension_s.SetError(Dimension_s, "Invalid");
                Validated = false;
            }
           
            // Hide message box
            pictureBox2.Visible = false;
            Message.Visible = false;
            Save.Visible = false;
            Label_fa.Visible = false;

            // Calculate suspension travel
            if (Validated)
            {
                 Fa = SuspensionTravel(Dim_a, Dim_b, Dim_c, Dim_d, Dim_L0, Dim_s);
                
                if (Fa <= 125)
                {
                    pictureBox2.Image = Image.FromFile(@"C:\Users\Rider\source\repos\AHRMA Suspension Validator\images\green-checkbox.jpg");
                    Message.Text = $"This bike is perfectly legal and ready to race!";
                    Label_fa.Text = Fa.ToString() + "mm";
                    Label_fa.Visible = true;
                }
                else
                {
                    double OverTheLimit = Math.Round( Fa - 125, 2);
                    int NumberOfShims = Convert.ToInt32((OverTheLimit / 25)) + 1;
                    pictureBox2.Image = Image.FromFile(@"C:\Users\Rider\source\repos\AHRMA Suspension Validator\images\Red-Xbox.jpg");
                    Message.Text = $"This bike is over the limit by {OverTheLimit} milimeters and will require {NumberOfShims} shims to be legal.";
                    Label_fa.Visible = false;
                }

                // Show message box
                pictureBox2.Visible = true;
                Message.Visible = true;
                Save.Visible = true;
            }
        }

        // Enter and Leave dimensions events 
        private void Dimension_a_Enter(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"C:\Users\Rider\source\repos\AHRMA Suspension Validator\images\Dimension_a.jpg");
            Instructions.Text = "Measure from swingarm pivot to rear axle.";
            pictureBox1.Visible = true;
            Instructions.Visible = true;   
        }
        private void Dimension_a_Leave(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;
            Instructions.Visible = false;
        }

        private void Dimension_b_Enter(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"C:\Users\Rider\source\repos\AHRMA Suspension Validator\images\Dimension_b.jpg");
            Instructions.Text = "Measure from swingarm pivot to 90 degree point on swingarm below lower shock mount and rear axle.";
            pictureBox1.Visible = true;
            Instructions.Visible = true;
        }
        private void Dimension_b_Leave(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;
            Instructions.Visible = false;
        }

        private void Dimension_c_Enter(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"C:\Users\Rider\source\repos\AHRMA Suspension Validator\images\Dimension_c.jpg");
            Instructions.Text = "Measure from swingarm pivot to the upper shock mount.";
            pictureBox1.Visible = true;
            Instructions.Visible = true;
        }
        private void Dimension_c_Leave(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;
            Instructions.Visible = false;
        }

        private void Dimension_d_Enter(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"C:\Users\Rider\source\repos\AHRMA Suspension Validator\images\Dimension_d.jpg");
            Instructions.Text = "Measure from lower shock mount to 90 degree point on swingarm below lower shock mount and rear axle.";
            pictureBox1.Visible = true;
            Instructions.Visible = true;
        }
        private void Dimension_d_Leave(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;
            Instructions.Visible = false;
        }

        private void Dimension_L0_Enter(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"C:\Users\Rider\source\repos\AHRMA Suspension Validator\images\Dimension_L0.jpg");
            Instructions.Text = "Measure from center of lower shock mount to the center of upper shock mount.";
            pictureBox1.Visible = true;
            Instructions.Visible = true;
        }
        private void Dimension_L0_Leave(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;
            Instructions.Visible = false;
        }

        private void Dimension_s_Enter(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"C:\Users\Rider\source\repos\Chapter3\AHRMA Suspension Validator\images\Dimension_s.jpg");
            Instructions.Text = "Measure the entire length of the internal shock shaft.";
            pictureBox1.Visible = true;
            Instructions.Visible = true;
        }
        private void Dimension_s_Leave(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;
            Instructions.Visible = false;
        }

        // Save racer info and dimensions to database.
        private void Save_Click(object sender, EventArgs e)
        {
            String SQLString =
            "Insert into Racers (Date, RacerName, BikeYear, BikeBrand, BikeModel, Dim_a, Dim_b, Dim_c, Dim_d, Dim_L0, Dim_s, Fa) values " +
            $"('{DateTime.Now}', '{RacerName.Text}', '{BikeYear.Text}', '{BikeBrand.Text}', '{BikeModel.Text}', '{Dim_a}', '{Dim_b}', '{Dim_c}', '{Dim_d}', '{Dim_L0}', '{Dim_s}', '{Fa}')";

            DbConnect.Open();
            SqlCommand SQLCmd = new SqlCommand(SQLString, DbConnect);
            SQLCmd.ExecuteNonQuery();
            DbConnect.Close();
            RefreshRacerGrid();
        }
        
        // Refresh racer grid method.
        private void RefreshRacerGrid()
        {
            DbConnect.Open();
            SqlCommand SQLCmd = new SqlCommand("Select * from Racers", DbConnect);
            SqlDataAdapter RacerGridAdapter = new SqlDataAdapter(SQLCmd);
            DataTable RacerGridTable = new DataTable();
            RacerGridAdapter.Fill(RacerGridTable);
            RacerGrid.DataSource = RacerGridTable;
            DbConnect.Close();
        }
        
        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void ClearForm_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}

