﻿namespace AHRMA_Suspension_Valididator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.BikeModel = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BikeBrand = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.BikeYear = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.RacerName = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Exit = new System.Windows.Forms.Button();
            this.Label_fa = new System.Windows.Forms.Label();
            this.Save = new System.Windows.Forms.Button();
            this.Message = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.ClearForm = new System.Windows.Forms.Button();
            this.Calculate = new System.Windows.Forms.Button();
            this.Dimension_s = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Dimension_L0 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Dimension_d = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Dimension_c = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Dimension_b = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Dimension_a = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.errorProvider_RacerName = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider_BikeYear = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider_BikeBrand = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider_BikeModel = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider_Dimension_a = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider_Dimension_b = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider_Dimension_c = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider_Dimension_d = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider_Dimension_L0 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider_Dimension_s = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Instructions = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.RacerGrid = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_RacerName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_BikeYear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_BikeBrand)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_BikeModel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Dimension_a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Dimension_b)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Dimension_c)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Dimension_d)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Dimension_L0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Dimension_s)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RacerGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.BikeModel);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.BikeBrand);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.BikeYear);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.RacerName);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(458, 135);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Racer And Biker Information";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(325, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Model:";
            // 
            // BikeModel
            // 
            this.BikeModel.Location = new System.Drawing.Point(328, 96);
            this.BikeModel.Name = "BikeModel";
            this.BikeModel.Size = new System.Drawing.Size(100, 22);
            this.BikeModel.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(166, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Brand:";
            // 
            // BikeBrand
            // 
            this.BikeBrand.FormattingEnabled = true;
            this.BikeBrand.Items.AddRange(new object[] {
            "Honda",
            "Yamaha",
            "Suzuki",
            "Kawasaki"});
            this.BikeBrand.Location = new System.Drawing.Point(169, 94);
            this.BikeBrand.Name = "BikeBrand";
            this.BikeBrand.Size = new System.Drawing.Size(121, 24);
            this.BikeBrand.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Year:";
            // 
            // BikeYear
            // 
            this.BikeYear.FormattingEnabled = true;
            this.BikeYear.Items.AddRange(new object[] {
            "1975",
            "1974",
            "1973",
            "1972",
            "1971",
            "1970"});
            this.BikeYear.Location = new System.Drawing.Point(9, 94);
            this.BikeYear.Name = "BikeYear";
            this.BikeYear.Size = new System.Drawing.Size(121, 24);
            this.BikeYear.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name:";
            // 
            // RacerName
            // 
            this.RacerName.Location = new System.Drawing.Point(9, 44);
            this.RacerName.Name = "RacerName";
            this.RacerName.Size = new System.Drawing.Size(281, 22);
            this.RacerName.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Exit);
            this.groupBox2.Controls.Add(this.Label_fa);
            this.groupBox2.Controls.Add(this.Save);
            this.groupBox2.Controls.Add(this.Message);
            this.groupBox2.Controls.Add(this.pictureBox2);
            this.groupBox2.Controls.Add(this.ClearForm);
            this.groupBox2.Controls.Add(this.Calculate);
            this.groupBox2.Controls.Add(this.Dimension_s);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.Dimension_L0);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.Dimension_d);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.Dimension_c);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.Dimension_b);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.Dimension_a);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(12, 170);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(458, 268);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Suspension Dimensions in Milimeters";
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.Red;
            this.Exit.ForeColor = System.Drawing.Color.White;
            this.Exit.Location = new System.Drawing.Point(244, 227);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 35);
            this.Exit.TabIndex = 19;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Label_fa
            // 
            this.Label_fa.BackColor = System.Drawing.Color.White;
            this.Label_fa.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_fa.Location = new System.Drawing.Point(272, 130);
            this.Label_fa.Name = "Label_fa";
            this.Label_fa.Size = new System.Drawing.Size(156, 26);
            this.Label_fa.TabIndex = 18;
            // 
            // Save
            // 
            this.Save.BackColor = System.Drawing.Color.Green;
            this.Save.ForeColor = System.Drawing.Color.White;
            this.Save.Location = new System.Drawing.Point(339, 227);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(75, 35);
            this.Save.TabIndex = 17;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = false;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // Message
            // 
            this.Message.BackColor = System.Drawing.Color.White;
            this.Message.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Message.Location = new System.Drawing.Point(266, 87);
            this.Message.Margin = new System.Windows.Forms.Padding(3);
            this.Message.Name = "Message";
            this.Message.Padding = new System.Windows.Forms.Padding(5);
            this.Message.Size = new System.Drawing.Size(174, 80);
            this.Message.TabIndex = 16;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(188, 87);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(78, 80);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // ClearForm
            // 
            this.ClearForm.Location = new System.Drawing.Point(136, 227);
            this.ClearForm.Name = "ClearForm";
            this.ClearForm.Size = new System.Drawing.Size(87, 35);
            this.ClearForm.TabIndex = 13;
            this.ClearForm.Text = "Clear";
            this.ClearForm.UseVisualStyleBackColor = true;
            this.ClearForm.Click += new System.EventHandler(this.ClearForm_Click);
            // 
            // Calculate
            // 
            this.Calculate.BackColor = System.Drawing.Color.RoyalBlue;
            this.Calculate.ForeColor = System.Drawing.Color.White;
            this.Calculate.Location = new System.Drawing.Point(0, 227);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(115, 35);
            this.Calculate.TabIndex = 12;
            this.Calculate.Text = "Calculate";
            this.Calculate.UseVisualStyleBackColor = false;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // Dimension_s
            // 
            this.Dimension_s.Location = new System.Drawing.Point(109, 187);
            this.Dimension_s.Name = "Dimension_s";
            this.Dimension_s.Size = new System.Drawing.Size(52, 22);
            this.Dimension_s.TabIndex = 11;
            this.Dimension_s.Enter += new System.EventHandler(this.Dimension_s_Enter);
            this.Dimension_s.Leave += new System.EventHandler(this.Dimension_s_Leave);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 190);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 16);
            this.label10.TabIndex = 10;
            this.label10.Text = "Dimension s:";
            // 
            // Dimension_L0
            // 
            this.Dimension_L0.Location = new System.Drawing.Point(109, 156);
            this.Dimension_L0.Name = "Dimension_L0";
            this.Dimension_L0.Size = new System.Drawing.Size(52, 22);
            this.Dimension_L0.TabIndex = 9;
            this.Dimension_L0.Enter += new System.EventHandler(this.Dimension_L0_Enter);
            this.Dimension_L0.Leave += new System.EventHandler(this.Dimension_L0_Leave);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 159);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 16);
            this.label9.TabIndex = 8;
            this.label9.Text = "Dimension L0:";
            // 
            // Dimension_d
            // 
            this.Dimension_d.Location = new System.Drawing.Point(109, 125);
            this.Dimension_d.Name = "Dimension_d";
            this.Dimension_d.Size = new System.Drawing.Size(52, 22);
            this.Dimension_d.TabIndex = 7;
            this.Dimension_d.Enter += new System.EventHandler(this.Dimension_d_Enter);
            this.Dimension_d.Leave += new System.EventHandler(this.Dimension_d_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 16);
            this.label8.TabIndex = 6;
            this.label8.Text = "Dimension d:";
            // 
            // Dimension_c
            // 
            this.Dimension_c.Location = new System.Drawing.Point(109, 92);
            this.Dimension_c.Name = "Dimension_c";
            this.Dimension_c.Size = new System.Drawing.Size(52, 22);
            this.Dimension_c.TabIndex = 5;
            this.Dimension_c.Enter += new System.EventHandler(this.Dimension_c_Enter);
            this.Dimension_c.Leave += new System.EventHandler(this.Dimension_c_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 95);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 16);
            this.label7.TabIndex = 4;
            this.label7.Text = "Dimension c:";
            // 
            // Dimension_b
            // 
            this.Dimension_b.Location = new System.Drawing.Point(109, 61);
            this.Dimension_b.Name = "Dimension_b";
            this.Dimension_b.Size = new System.Drawing.Size(52, 22);
            this.Dimension_b.TabIndex = 3;
            this.Dimension_b.Enter += new System.EventHandler(this.Dimension_b_Enter);
            this.Dimension_b.Leave += new System.EventHandler(this.Dimension_b_Leave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Dimension b:";
            // 
            // Dimension_a
            // 
            this.Dimension_a.Location = new System.Drawing.Point(109, 33);
            this.Dimension_a.Name = "Dimension_a";
            this.Dimension_a.Size = new System.Drawing.Size(52, 22);
            this.Dimension_a.TabIndex = 1;
            this.Dimension_a.Enter += new System.EventHandler(this.Dimension_a_Enter);
            this.Dimension_a.Leave += new System.EventHandler(this.Dimension_a_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "Dimension a:";
            // 
            // errorProvider_RacerName
            // 
            this.errorProvider_RacerName.ContainerControl = this;
            // 
            // errorProvider_BikeYear
            // 
            this.errorProvider_BikeYear.ContainerControl = this;
            // 
            // errorProvider_BikeBrand
            // 
            this.errorProvider_BikeBrand.ContainerControl = this;
            // 
            // errorProvider_BikeModel
            // 
            this.errorProvider_BikeModel.ContainerControl = this;
            // 
            // errorProvider_Dimension_a
            // 
            this.errorProvider_Dimension_a.ContainerControl = this;
            // 
            // errorProvider_Dimension_b
            // 
            this.errorProvider_Dimension_b.ContainerControl = this;
            // 
            // errorProvider_Dimension_c
            // 
            this.errorProvider_Dimension_c.ContainerControl = this;
            // 
            // errorProvider_Dimension_d
            // 
            this.errorProvider_Dimension_d.ContainerControl = this;
            // 
            // errorProvider_Dimension_L0
            // 
            this.errorProvider_Dimension_L0.ContainerControl = this;
            // 
            // errorProvider_Dimension_s
            // 
            this.errorProvider_Dimension_s.ContainerControl = this;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Instructions);
            this.groupBox3.Controls.Add(this.pictureBox1);
            this.groupBox3.Location = new System.Drawing.Point(483, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(271, 426);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Visual Measurement Helper";
            // 
            // Instructions
            // 
            this.Instructions.BackColor = System.Drawing.Color.White;
            this.Instructions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Instructions.Location = new System.Drawing.Point(23, 314);
            this.Instructions.Name = "Instructions";
            this.Instructions.Padding = new System.Windows.Forms.Padding(5);
            this.Instructions.Size = new System.Drawing.Size(216, 78);
            this.Instructions.TabIndex = 20;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Location = new System.Drawing.Point(6, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(245, 384);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.RacerGrid);
            this.groupBox4.Location = new System.Drawing.Point(12, 480);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(742, 240);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Racer Data";
            // 
            // RacerGrid
            // 
            this.RacerGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.RacerGrid.Location = new System.Drawing.Point(10, 21);
            this.RacerGrid.Name = "RacerGrid";
            this.RacerGrid.RowHeadersWidth = 51;
            this.RacerGrid.RowTemplate.Height = 24;
            this.RacerGrid.Size = new System.Drawing.Size(726, 213);
            this.RacerGrid.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(800, 762);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "AHRMA Suspension Validator";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_RacerName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_BikeYear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_BikeBrand)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_BikeModel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Dimension_a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Dimension_b)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Dimension_c)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Dimension_d)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Dimension_L0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Dimension_s)).EndInit();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.RacerGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox BikeYear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox RacerName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox BikeModel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox BikeBrand;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox Dimension_a;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Dimension_s;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Dimension_L0;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Dimension_d;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Dimension_c;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Dimension_b;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button ClearForm;
        private System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.ErrorProvider errorProvider_RacerName;
        private System.Windows.Forms.ErrorProvider errorProvider_BikeYear;
        private System.Windows.Forms.ErrorProvider errorProvider_BikeBrand;
        private System.Windows.Forms.ErrorProvider errorProvider_BikeModel;
        private System.Windows.Forms.ErrorProvider errorProvider_Dimension_a;
        private System.Windows.Forms.ErrorProvider errorProvider_Dimension_b;
        private System.Windows.Forms.ErrorProvider errorProvider_Dimension_c;
        private System.Windows.Forms.ErrorProvider errorProvider_Dimension_d;
        private System.Windows.Forms.ErrorProvider errorProvider_Dimension_L0;
        private System.Windows.Forms.ErrorProvider errorProvider_Dimension_s;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Message;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Label Label_fa;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView RacerGrid;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Label Instructions;
    }
}

